import { Button, Typography } from '@mui/material'
import React, { useState } from 'react'

const Count = () => {
    const [count, setCount] = useState(0)
     const increment  = ()=>{
        setCount(count+1)
     }
     const decrement  = ()=>{
        if(count>0)
        setCount(count-1)
     }
  return (
    <div>
        <Typography>Count:{count}</Typography>
        <Button onClick={increment} variant='contained'color="success">+</Button>
        <Button onClick={decrement} variant='contained'color="error">-</Button>
    </div>
  )
}

export default Count