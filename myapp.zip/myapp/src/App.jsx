import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import Login from './components/Login'
import Signup from './components/signup'
import Navbar from './components/Navbar'
import StateBasic from './components/StateBasic'
import Count from './components/Count'
import UseE from './components/UseE'
import Mapping from './components/Mapping'
import TableArray from './components/TableArray'

function App() {
  const[count,setCount]=useState(0)

  return (
      <>
      {/* <Login/> */}
      {/* <Signup/> */}
      <Navbar/>
      {/* <StateBasic/> */}
      {/* <Count/> */}
      {/* <UseE/> */}
      {/* <Mapping/> */}
      <TableArray/>
      </>
  )
}

export default App
